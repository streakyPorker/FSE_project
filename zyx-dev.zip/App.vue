<template>
  <v-app>
    <v-banner color="#D1C4E9" class="#8e24aa--text">
      欢迎来到疫情发布界面
      <template v-slot:actions>
        <router-link to="/manual">
          <v-btn text color="primary">管理员手动发布</v-btn>
        </router-link>
        <router-link to="/auto">
          <v-btn text color="primary">管理员设置自动发布</v-btn>
        </router-link>
        <router-link to="/globalauto">
          <v-btn text color="primary">全国管理员设置自动发布</v-btn>
        </router-link>
        <router-link to="/globalmanual">
          <v-btn text color="primary">全国管理员设置手动发布</v-btn>
        </router-link>
      </template>
    </v-banner>
    <main>
      <router-view></router-view>
    </main>
  </v-app>
</template>

<script>
export default{
  data () {
    return {
    }
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
